// nn bb ss u // 
let a = 45 ;
console.log(a)
let b = "pqr";
console.log(b)